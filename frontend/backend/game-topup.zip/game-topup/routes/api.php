<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\UserController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\PaymentController;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
| هون كل المسارات تبع الموقع.
| Laravel بيضيف /api قبل أي مسار بشكل تلقائي.
|--------------------------------------------------------------------------
*/

// ✅ مستخدمين
Route::apiResource('users', UserController::class);

// ✅ المنتجات (شدات، بطاقات..)
Route::apiResource('products', ProductController::class);

// ✅ الطلبات
Route::apiResource('orders', OrderController::class);

// ✅ المدفوعات
Route::apiResource('payments', PaymentController::class);
